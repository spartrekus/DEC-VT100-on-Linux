


#include <stdio.h> 
#include <stdlib.h> 
#include <termcap.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h> //
// for fexist
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
#include <unistd.h>  
#include <time.h>

#define PAMAX 250


char *strtimenow()
{
      long t;
      struct tm *ltime;
      time(&t);
      ltime=localtime(&t);
      char charo[50];  int fooi ; 
      fooi = snprintf( charo, 50 , 
	"%02d:%02d:%02d",
	ltime->tm_hour, ltime->tm_min, ltime->tm_sec 
	);

    size_t siz = sizeof charo ; 
    char *r = malloc( sizeof charo );
    return r ? memcpy(r, charo, siz ) : NULL;
}



void clear_screen()
{
       char buf[1024];
       char *str;
       tgetent(buf, getenv("TERM"));
       str = tgetstr( "cl" , NULL);
       fputs( str, stdout );

}

int bin_welcome()
{
  printf( "\n" );
  printf( "BSD/X-20M(GNU) Version 1.0  \n" );
  printf( "Copyleft (C) 1978 GNU Research, Inc. \n ");
  printf( "\n" );
}

int enter_getchr()
{
   printf( "<Enter Command>\n" ); 
   getchar();
}


void bin_ls()
{
    DIR *dirp;
    struct dirent *dp;
    dirp = opendir( "." );
    while ((dp = readdir( dirp )) != NULL )
         printf( "%s\n", dp->d_name );
    closedir( dirp );
}

int enter_cmd()
{
   char inputline[PAMAX];
   char cwd[PATH_MAX];
   int foout = 1;
   printf( "\n" ); 
   printf( "[DEC-VT100][%s] A> ", strtimenow());
   scanf("%s", &inputline);

   if ( strcmp( inputline, "pwd" ) == 0 ) 
     printf( "%s" ,getcwd( cwd, PATH_MAX ) );
   else if ( strcmp( inputline, "welcome" ) == 0 ) 
     bin_welcome();
   else if ( strcmp( inputline, "clr" ) == 0 ) 
     clear_screen();
   else if ( strcmp( inputline, "ls" ) == 0 ) 
   {
     bin_ls();
   }
   else if ( strcmp( inputline, "help" ) == 0 ) 
   {
      printf( "## HELP ##\n");
      printf( "ls, pwd, welcome, clr are your commands.\n");
   }
   else if ( strcmp( inputline, "nc" ) == 0 ) 
     system( " nc " );
   else if ( strcmp( inputline, "quit" ) == 0 ) 
       foout = 0;

   return foout; 
}


/////////////////
int main()  
{  
   clear_screen();
   bin_welcome();
   int looping = 1;
   while( looping == 1 )
     looping = enter_cmd(); 
   return 0;
}






